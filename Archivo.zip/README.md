# Guía de Usuario: Módulo API Personalizado para Drupal

## Índice
1. Introducción
2. Requisitos previos
3. Instalación
4. Configuración
5. Uso del módulo
6. Personalización
7. Solución de problemas
8. Preguntas frecuentes

## 1. Introducción

Este módulo personalizado para Drupal permite a los usuarios configurar y realizar llamadas a una API externa de forma segura, encriptando el token de acceso.

## 2. Requisitos previos

- Drupal 10.3.2 o superior
- Módulos requeridos:
  - Encrypt
  - Real AES

## 3. Instalación

1. Descarga el módulo y colócalo en la carpeta `modules/custom/` de tu instalación de Drupal.

2. Instala las dependencias usando Composer:
   ```
   composer require drupal/encrypt drupal/real_aes
   ```

3. Habilita el módulo y sus dependencias desde la interfaz de administración de Drupal o usando Drush:
   ```
   drush en mi_modulo_api encrypt real_aes
   ```

## 4. Configuración

### 4.1 Configurar la encriptación

1. Ve a `Administración > Configuración > Sistema > Claves`.
2. Crea una nueva clave de encriptación:
   - Haz clic en "Add encryption key".
   - Dale un nombre (por ejemplo, "Mi Clave API").
   - Selecciona un Tipo de Clave ( "Encryption" ).
   - Selecciona el tamaño de clave ( "256" ).
   - Selecciona el Proveedor de Clave ( "Archivo" ).
   - Escribe la ruta al archivo de clave ( "../private/secret.key" ).
      - Genera el archivo de clave secrect.key ejecutando este comando desde el directorio raíz del proyecto: `dd if=/dev/urandom bs=32 count=1 > private/secret.key`
      https://www.drupal.org/project/real_aes
   - Guarda la clave.

3. Ve a `Administración > Configuración > Sistema > Encryption profiles`.
   - Haz clic en "Add encryption profile".
   - Dale un nombre ( "real_aes" ). ASI DEBE LLAMARLO
   - Selecciona "Real AES" como método de encriptación.
   - Selecciona la clave que creaste en el paso anterior.
   - Guarda el perfil.

### 4.2 Configurar el módulo API

1. Ve a `Administración > Configuración > Servicios Web > Mi Módulo API`.
2. Ingresa la URL de la API que deseas usar.
3. Ingresa el token de acceso a la API (será encriptado antes de almacenarse).
4. Guarda la configuración.

## 5. Uso del módulo

1. Navega a la página del formulario API (la ruta dependerá de cómo hayas configurado el módulo, por ejemplo, `/mi-formulario-api`).
2. Verás un formulario con los campos que configuraste.
3. Completa los campos según sea necesario.
4. Envía el formulario para realizar la llamada a la API.
5. Verás un mensaje de éxito o error dependiendo del resultado de la llamada.

## 6. Personalización

### 6.1 Modificar campos de la API

1. Ve a la página de configuración del módulo.
2. Añade, modifica o elimina campos según sea necesario.
3. Guarda la configuración.
4. Limpia la caché de Drupal (`drush cr` o desde la interfaz de administración).

### 6.2 Cambia la visualización del resultado del formulario
  Personaliza la visualización editando la plantilla Twig en `templates/mi-modulo-api-form.html.twig`

### 6.3 Cambiar la URL o el token de la API

1. Ve a la página de configuración del módulo.
2. Actualiza la URL o el token según sea necesario.
3. Guarda la configuración.

### 6.4 Modificar el perfil de encriptación

Si necesitas cambiar el método de encriptación:
1. Crea un nuevo perfil de encriptación como se describe en la sección 4.1.
2. Modifica el archivo `MiModuloApiSettingsForm.php` para usar el nuevo perfil.
3. Limpia la caché de Drupal.

## 7. Solución de problemas

- **Error al guardar el token**: Asegúrate de que el perfil de encriptación "real_aes" existe y está configurado correctamente.
- **Error 401 al llamar a la API**: Verifica que el token de acceso sea correcto y esté vigente.
- **Campos no aparecen en el formulario**: Limpia la caché de Drupal y verifica la configuración del módulo.
- **Error de encriptación**: Asegúrate de que los módulos Encrypt y Real AES estén habilitados y configurados correctamente.

## 8. Preguntas frecuentes

**P: ¿Puedo usar este módulo con cualquier API?**
R: Sí, siempre que la API acepte los campos que configures y utilice autenticación por token.

**P: ¿El token está seguro?**
R: Sí, el token se encripta antes de almacenarse en la base de datos de Drupal.

**P: ¿Puedo modificar cómo se procesa la respuesta de la API?**
R: Sí, pero esto requeriría modificar el código del módulo. Consulta la documentación de desarrollo para más información.

Para más información, consulta la documentación completa o contacta al equipo de desarrollo.
