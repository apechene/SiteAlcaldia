<?php

namespace Drupal\mi_modulo_api;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Site\Settings;
use Drupal\encrypt\Entity\EncryptionProfile;

class ApiTokenManager {
  protected $configFactory;
  protected $settings;

  public function __construct(
    ConfigFactoryInterface $config_factory,
    Settings $settings
  ) {
  $this->configFactory = $config_factory;
  $this->settings = $settings;
  }

  public function getToken() {
    // Primero, intenta obtener el token de las configuraciones del sitio
    $token = $this->settings->get('mi_modulo_api_token');

    // Si no está en las configuraciones, obtenerlo de la base de datos
    if (!$token) {
      $encrypted_token = $this->configFactory->get('mi_modulo_api.settings')->get('api_token');
      if ($encrypted_token) {
        $encryption_profile = EncryptionProfile::load('real_aes');
        if ($encryption_profile) {
          $token = \Drupal::service('encryption')->decrypt($encrypted_token, $encryption_profile);
        }
      }
    }
  #\Drupal::logger('mi_modulo_api')->notice('Token obtenido: @token', ['@token' => $token ? 'Sí' : 'No']);
    return $token;
  }
}
