<?php

namespace Drupal\mi_modulo_api\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\mi_modulo_api\ApiTokenManager;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\ClientException;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\ReplaceCommand;
use Drupal\Core\Ajax\RedirectCommand;
use Drupal\Core\Ajax;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Ajax\ScrollTopCommand;



$form['#attached']['library'][] = 'core/drupal.ajax';




class MiFormularioApi extends FormBase
{
    protected $httpClient;
    protected $tokenManager;
    protected $configFactory;

    public function __construct(
        ClientInterface $http_client,
        ApiTokenManager $token_manager,
        ConfigFactoryInterface $config_factory
    ) {
        $this->httpClient = $http_client;
        $this->tokenManager = $token_manager;
        $this->configFactory = $config_factory;
    }

    public static function create(ContainerInterface $container)
    {
        return new static(
            $container->get("http_client"),
            $container->get("mi_modulo_api.token_manager"),
            $container->get("config.factory")
        );
    }

    public function getFormId()
    {
        return "mi_formulario_api";
    }
   
   
    public function buildForm(array $form, FormStateInterface $form_state)
    {

        $form['#attached']['library'][] = 'views/views.ajax'; 
        $form['#attached']['library'][] = 'mi_modulo_api/scroll_top';

        $form["tipo_documento"] = [
            "#type" => "select",
            "#title" => $this->t("Tipo Documento"),
            "#options" => [
                "CC" => $this->t("Cédula"),
                "NIT" => $this->t("Nit"),
                "CE" => $this->t("Cédula de Extranjería"),
                "TI" => $this->t("Tarjeta de Identidad"),
            ],
            "#required" => true,
            //"#attributes" => ["class" => [""]], // Clase personalizada
        ];

        $form["num_documento"] = [
            "#type" => "number",
            "#title" => $this->t("Número de documento"),
            "#required" => true,
            "#size" => 15,
            "#maxlength" => 20,
            "#placeholder" => "Ingrese su numero doc.",
            //"#attributes" => ["class" => [""]], // Clase personalizada
        ];

        $form["num_radicado"] = [
            "#type" => "number",
            "#title" => $this->t("Radicado"),
            "#required" => true,
            "#size" => 12,
            "#maxlength" => 15,
            "#placeholder" => "Ingrese su radicado",
            //"#attributes" => ["class" => [""]], // Clase personalizada
        ];

        $form["num_vigencia"] = [
            "#type" => "textfield",
            "#title" => $this->t("Vigencia"),
            "#required" => TRUE,
            '#attributes' => [
                'autocomplete' => 'off',
                'class' => ['js-datepicker-years-filter', 'form-text', 'form-control', 'rounded-pill'],
                'size' => 10, // Tamaño del campo como en el HTML.
                'maxlength' => 4, // Solo 4 caracteres para el año.
              ],
             '#placeholder' => $this->t('Año'),
             '#default_value' => '',
             '#element_validate' => ['::validateVigencia'],
        ];

        $form['api_response_container'] = [
            '#type' => 'container',
            '#attributes' => ['id' => 'api-response-wrapper'],
        ];
        $form['messages'] = [
            '#type' => 'container',
            '#attributes' => ['id' => 'result_message'],
        ];
        

        $form['submit'] = [
            '#type' => 'submit',
            '#value' => $this->t('Consultar'),
            '#attributes' => [
                'class' => [
                    'btn',
                    'btn-md',
                    'btn-primary'
                ],
            ],
            '#ajax' => [
                'callback' => '::sendform',
                'disable-refocus' => TRUE,
                'event' => 'click',
                'wrapper' => 'api-response-wrapper',
                'progress' => [
                    'type' => 'throbber',
                    'message' => $this->t('Consultando...'),
                ],
            ],
          
        ];


        $form["#theme"] = "mi_formulario_api";
        $form["#attached"]["library"][] = "mi_modulo_api/mi_modulo_api_styles";

      
       return $form;
    }

   

    public function validateVigencia(array &$element, FormStateInterface $form_state, array &$complete_form) {
        // aqui se obtiene el valor ingresado por el usuario.
        $value = $form_state->getValue($element['#parents']);
      
        // eliminamos los espacios en blanco.
        $value = trim($value);
      
        // Verificar si el valor tiene exactamente 4 dígitos.
        if (!preg_match('/^\d{4}$/', $value)) {
          // Si no es válido, establecer un mensaje de error.
          $form_state->setError($element, $this->t('El año ingresado no es válido. Debe ser un número de 4 dígitos.'));
        }
      
        // Guardar el valor limpio en el estado del formulario.
        $form_state->setValueForElement($element, $value);
      }

      public function validateForm(array &$form, FormStateInterface $form_state) {
        // Validación para asegurar que el campo número de documento no esté vacío
        if (empty($form_state->getValue('num_documento'))) {
            $form_state->setErrorByName('num_documento', $this->t('El Número de Documento es obligatorio.'));
        }

        // Validación para asegurar que el tipo de documento esté seleccionado
        if (empty($form_state->getValue('num_radicado'))) {
            $form_state->setErrorByName('num_radicado', $this->t('El Radicado es obligatorio.'));
        }

    }

    public function submitForm(array &$form, FormStateInterface $form_state)
    {
        //$values = $form_state->getValues();
        $config = $this->configFactory->get("mi_modulo_api.settings");
        $api_url = $config->get("api_url");
        $api_token = $this->tokenManager->getToken();

        if (!$api_token) {
            $this->messenger()->addError(
                $this->t(
                    "No se pudo obtener el token de API. Por favor, verifique la configuración."
                )
            );
            return;
        }

        try {
            $response = $this->httpClient->request("POST", $api_url, [
                "json" => [
                    "tipoIdentificacion" => $form_state->getValue(
                        "tipo_documento"
                    ),
                    "numeroIdentificacion" => $form_state->getValue(
                        "num_documento"
                    ),
                    "radicado" => $form_state->getValue("num_radicado"),
                    "vigencia" => $form_state->getValue("num_vigencia"),
                ],
                "headers" => [
                    "X-API-Key" => $api_token,
                    "Content-Type" => "application/json",
                ],
            ]);

            // Logging the parameters sent to the API
            \Drupal::logger("mi_modulo_api")->notice(
                "Parámetros enviados a la API: @params",
                [
                    "@params" => json_encode([
                        "tipoIdentificacion" => $form_state->getValue(
                            "tipo_documento"
                        ),
                        "numeroIdentificacion" => $form_state->getValue(
                            "num_documento"
                        ),
                        "radicado" => $form_state->getValue("num_radicado"),
                        "vigencia" => $form_state->getValue("num_vigencia"),
                    ]),
                ]
            );

            $result = json_decode($response->getBody()->getContents(), true);
            // Log the API response
            \Drupal::logger("mi_modulo_api")->notice(
                "Respuesta de la API: @response",
                [
                    "@response" => json_encode($result),
                ]
            );

            if (!empty($result)) {
                $form_state->set("api_response", $result);
                $formattedData = $this->formatApiResponse($result);
                $form_state->set("api_response_formatted", $formattedData);
                $this->messenger()->addMessage(
                    $this->t("Se ha encontrado la siguiente información: ")
                );
            } else {
                // Limpiar los datos anteriores si la consulta no trae resultados
                $form_state->set("api_response", null);
                $form_state->set("api_response_formatted", null);
                $this->messenger()->addMessage(
                    $this->t(
                        "La consulta se realizó correctamente, pero no se encontraron datos que cumplan con los criterios de búsqueda."
                    )
                );
            }
            $form_state->setRebuild(true);
        } catch (ClientException $e) {
            // Limpiar los datos anteriores en caso de error
            $form_state->set("api_response", null);
            $form_state->set("api_response_formatted", null);

            if ($e->getResponse()->getStatusCode() == 404) {
                $errorBody = json_decode($e->getResponse()->getBody(), true);
                $errorMessage =
                    $errorBody["message"] ??
                    "No se encontraron registros para esta consulta.";
                $this->messenger()->addWarning($this->t($errorMessage));

                // Log el error completo para fines de depuración, pero no lo muestres al usuario
                \Drupal::logger("mi_modulo_api")->error(
                    "Error API en registros: @message",
                    ["@message" => $e->getMessage()]
                );
            } else {
                $error_message = $this->t(
                    "Error en la solicitud: Los datos proporcionados no son válidos o hubo un problema de conexión. Por favor, verifique la información e intente de nuevo."
                );

                // Log el error completo para fines de depuración, pero no lo muestres al usuario
                \Drupal::logger("mi_modulo_api")->error(
                    "Error API en la solicitud: @message",
                    ["@message" => $e->getMessage()]
                );

                $this->messenger()->addError($error_message);
            }

            // Log the API response
            \Drupal::logger("mi_modulo_api")->notice(
                "Respuesta de la API: @error",
                [
                    "@error" => $e->getMessage(),
                ]
            );
        } catch (\Exception $e) {
            // Limpiar los datos anteriores en caso de error
            $form_state->set("api_response", null);
            $form_state->set("api_response_formatted", null);

            $error_message = $this->t(
                "Error al conectar con la API. Por favor, verifique la información e intente de nuevo."
            );
            // Log el error completo para fines de depuración, pero no lo muestres al usuario
            \Drupal::logger("mi_modulo_api")->error(
                "Error API en la Conexion: @message",
                ["@message" => $e->getMessage()]
            );
            $this->messenger()->addError($error_message);
        }

        $form_state->setRebuild(true);
    }


    protected function buildApiResponseMarkup(array $formattedData) {
        $output = '<hr/><div class="row"><h2>' . $this->t('Datos de la cuenta') . '</h2></div>';
        if (!empty($formattedData['header'])) {
            $output .= '<div class="row">';
            foreach ($formattedData['header'] as $key => $value) {
                $output .= '<div class="col-12"><strong>' . $key . ':</strong> ' . $value . '</div>';
            }
            $output .= '</div>';
        }
        if (!empty($formattedData['eventos'])) {
            $output .= '<div class="row"><h2>' . $this->t('Estado de la cuenta') . '</h2></div>';
            $output .= '<table class="table table-striped"><thead><tr><th>Fecha</th><th>Evento</th><th>Observaciones</th></tr></thead><tbody>';
            foreach ($formattedData['eventos'] as $evento) {
                $output .= '<tr><td>' . $evento['Fecha'] . '</td><td>' . $evento['Evento'] . '</td><td>' . $evento['Observaciones'] . '</td></tr>';
            }
            $output .= '</tbody></table>';
        } else {
            $output .= '<p>' . $this->t('No hay eventos disponibles.') . '</p>';
        }
        return $output;
    }


    /**
     * Formats the API response for display.
     *
     * @param array $response
     *   The API response.
     *
     * @return string
     *   Formatted HTML string.
     */
    protected function formatApiResponse(array $data)
    {
        #$output = '<div class="api-response">';
        $formattedData = [
            "header" => [
                "Identificacion" => $data["Identificacion"] ?? "No disponible",
                "Nombres" => $data["Nombres"] ?? "No disponible",
                "tipoPago" => $data["tipoPago"] ?? "No disponible",
                "Periodo" => $data["Periodo"] ?? "No disponible",
                "Vigencia" => $data["Vigencia"] ?? "No disponible",
            ],
            "eventos" => [],
        ];

        if (isset($data["eventos"]) && is_array($data["eventos"])) {
            foreach ($data["eventos"] as $evento) {
                $formattedData["eventos"][] = [
                    "Fecha" => $evento["Fecha"] ?? "No disponible",
                    "Evento" => $evento["Evento"] ?? "No disponible",
                    "Observaciones" =>
                        $evento["Observaciones"] ?? "No disponible",
                ];
            }
        }

        return $formattedData;
    }
    
    
    public function sendform(array &$form, FormStateInterface $form_state) {
        // Obtén la respuesta de la API y los datos formateados
        $api_response = $form_state->get("api_response");
        $formattedData = $form_state->get("api_response_formatted");
    
        $response = new AjaxResponse();
    
        // Verifica si hay respuesta de la API
        if ($api_response && !empty($api_response)) {
            // Renderiza únicamente el contenido del contenedor `api-response-wrapper`
            $output = [
                '#theme' => 'mi_formulario_api', // Asegúrate de que tienes un template específico para los resultados.
                '#data' => $formattedData,
            ];
            $rendered_output = \Drupal::service('renderer')->renderRoot($output);
            $response->addCommand(new HtmlCommand('#api-response-wrapper', $rendered_output));
    
            
        } else {

            
            // En caso de que no se encuentren datos
            $response->addCommand(new HtmlCommand('#api-response-wrapper', $this->t('')));
        }
    
        // Actualiza el contenedor de mensajes
        $rendered_messages = ['#type' => 'status_messages'];
        $response->addCommand(new HtmlCommand('#result_message', \Drupal::service('renderer')->renderRoot($rendered_messages)));
    
        return $response;
    }
    
    
    
    
    
    
 
}
