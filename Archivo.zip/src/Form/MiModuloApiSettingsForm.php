<?php

namespace Drupal\mi_modulo_api\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\encrypt\Entity\EncryptionProfile;
use Symfony\Component\DependencyInjection\ContainerInterface;

class MiModuloApiSettingsForm extends ConfigFormBase {

  protected function getEditableConfigNames() {
    return ['mi_modulo_api.settings'];
  }

  public function getFormId() {
    return 'mi_modulo_api_settings';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('mi_modulo_api.settings');

    $form['api_url'] = [
      '#type' => 'url',
      '#title' => $this->t('URL de la API'),
      '#default_value' => $config->get('api_url'),
      '#required' => TRUE,
    ];

    $form['api_token'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Token de acceso'),
      '#default_value' => $config->get('api_token') ? '[TOKEN ENCRIPTADO]' : '',
      '#description' => $this->t('Ingrese el token de API completo. Será encriptado antes de almacenarse.'),
      '#required' => TRUE,
    ];

    return parent::buildForm($form, $form_state);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
  $token = $form_state->getValue('api_token');

  $encryption_profile = EncryptionProfile::load('real_aes');

  if (!$encryption_profile) {
    $this->messenger()->addError($this->t('No se pudo encontrar el perfil de encriptación "real_aes". Por favor, verifique la configuración de encriptación.'));
    return;
  }

  $encrypted_token = \Drupal::service('encryption')->encrypt($token, $encryption_profile);

    $this->config('mi_modulo_api.settings')
      ->set('api_url', $form_state->getValue('api_url'))
      ->set('api_token', $encrypted_token)
      ->save();

    $this->messenger()->addMessage($this->t('El token de API ha sido encriptado y guardado exitosamente.'));
   parent::submitForm($form, $form_state);
  }
}
